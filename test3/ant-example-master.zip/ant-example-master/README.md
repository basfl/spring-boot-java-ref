# Example of ActiveJDBC using Ant

To execute:

1. Run create.sql against your instance of MySQL - this will create a new table. 
2. Execute: "ant run" in this directory
